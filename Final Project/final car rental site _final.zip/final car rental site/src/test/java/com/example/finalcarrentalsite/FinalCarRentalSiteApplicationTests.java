package com.example.finalcarrentalsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalCarRentalSiteApplicationTests {

    @Test
    void contextLoads() {
    }

}
