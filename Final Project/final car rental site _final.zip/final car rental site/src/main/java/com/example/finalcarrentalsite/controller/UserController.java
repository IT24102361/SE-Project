package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.user;
import com.example.finalcarrentalsite.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

@Controller
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/user/register")
    public String showRegister(@RequestParam(value = "returnUrl", required = false) String returnUrl, Model model) {
        model.addAttribute("returnUrl", returnUrl);
        return "user_register";
    }

    @PostMapping("/user/register")
    public String doRegister(@RequestParam String username,
                             @RequestParam String password,
                             @RequestParam String email,
                             @RequestParam String phoneNumber,
                             @RequestParam(value = "returnUrl", required = false) String returnUrl,
                             Model model,
                             HttpSession session) {
        user newUser = new user();
        newUser.setUsername(username);
        newUser.setPassword(password);
        newUser.setEmail(email);
        newUser.setPhoneNumber(phoneNumber);
        userRepository.save(newUser);
        String target = (returnUrl != null && !returnUrl.isBlank()) ? returnUrl : "/cars";
        return "redirect:/user/login?message=Registration%20successful.%20Please%20log%20in.";
    }

    @GetMapping("/user/login")
    public String showLogin(@RequestParam(value = "returnUrl", required = false) String returnUrl,
                            @RequestParam(value = "message", required = false) String message,
                            Model model) {
        model.addAttribute("returnUrl", returnUrl);
        model.addAttribute("message", message);
        return "user_login";
    }

    @PostMapping("/user/login")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          @RequestParam(value = "returnUrl", required = false) String returnUrl,
                          Model model,
                          HttpSession session) {
        Optional<user> existing = userRepository.findByUsernameAndPassword(username, password);
        if (existing.isPresent()) {
            session.setAttribute("role", "USER");
            session.setAttribute("username", existing.get().getUsername());
            model.addAttribute("user", existing.get());
            return "redirect:" + (returnUrl != null && !returnUrl.isBlank() ? returnUrl : "/cars");
        }
        model.addAttribute("error", "Invalid credentials");
        return "user_login";
    }

    @GetMapping("/user/dashboard")
    public String userDashboard(HttpSession session, Model model) {
        Object username = session.getAttribute("username");
        if (username == null) {
            return "redirect:/user/login";
        }
        model.addAttribute("username", username);
        return "user_dashboard";
    }
} 