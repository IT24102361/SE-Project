package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.Car;
import com.example.finalcarrentalsite.entity.Promotion;
import com.example.finalcarrentalsite.repository.CarRepository;
import com.example.finalcarrentalsite.service.PromotionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/cars")
public class CarController {

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private PromotionService promotionService;

    private boolean isAdmin(HttpSession session) {
        Object role = session.getAttribute("role");
        return role != null && "ADMIN".equals(role.toString());
    }

    private boolean isAdminOrDriver(HttpSession session) {
        Object role = session.getAttribute("role");
        return role != null && ("ADMIN".equals(role.toString()) || "DRIVER".equals(role.toString()));
    }

    // Show all cars
    @GetMapping
    public String getAllCars(Model model) {
        List<Car> cars = carRepository.findAll();
        List<Promotion> activePromotions = promotionService.getAllActivePromotions();
        
        model.addAttribute("cars", cars);
        model.addAttribute("activePromotions", activePromotions);
        return "car"; // refers to car.html (Thymeleaf template)
    }

    // Show car details
    @GetMapping("/{id}")
    public String getCarById(@PathVariable("id") Integer id, Model model) {
        Car car = carRepository.findById(id).orElse(null);
        model.addAttribute("car", car);
        return "car-details"; // refers to car-details.html
    }

    // Add a new car (form submit)
    @PostMapping
    public String addCar(@ModelAttribute Car car, HttpSession session) {
        if (!isAdminOrDriver(session)) {
            return "redirect:/adminLogin";
        }
        carRepository.save(car);
        return "redirect:/cars";
    }

    // Delete a car
    @GetMapping("/delete/{id}")
    public String deleteCar(@PathVariable("id") Integer id, HttpSession session) {
        if (!isAdmin(session)) {
            return "redirect:/adminLogin";
        }
        carRepository.deleteById(id);
        return "redirect:/cars";
    }

    // Show add form
    @GetMapping("/add")
    public String showAddForm(Model model, HttpSession session) {
        if (!isAdminOrDriver(session)) {
            return "redirect:/adminLogin";
        }
        model.addAttribute("car", new Car());
        return "addcar";
    }

    // Show edit form
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model, HttpSession session) {
        if (!isAdmin(session)) {
            return "redirect:/adminLogin";
        }
        Car car = carRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Car not found: " + id));
        model.addAttribute("car", car);
        return "edit-car";
    }

    // Save edited car
    @PostMapping("/update/{id}")
    public String updateCar(@PathVariable("id") Integer id, @ModelAttribute Car updatedCar, HttpSession session) {
        if (!isAdmin(session)) {
            return "redirect:/adminLogin";
        }
        updatedCar.setCarId(id);
        carRepository.save(updatedCar);
        return "redirect:/cars";
    }
}

