package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.Booking;
import com.example.finalcarrentalsite.repository.DriverRepository;
import com.example.finalcarrentalsite.repository.UserRepository;
import com.example.finalcarrentalsite.repository.BookingRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class AdminManagementController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private DriverRepository driverRepository;
    @Autowired
    private BookingRepository bookingRepository;

    @GetMapping("/admin/dashboard")
    public String dashboard(Model model, HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }
        
        // Get user and driver counts
        long userCount = userRepository.count();
        long driverCount = driverRepository.count();
        long bookingCount = bookingRepository.count();
        
        // Get recent bookings
        List<Booking> recentBookings = bookingRepository.findAll().stream()
            .limit(5)
            .collect(java.util.stream.Collectors.toList());
        
        model.addAttribute("users", userRepository.findAll());
        model.addAttribute("drivers", driverRepository.findAll());
        model.addAttribute("userCount", userCount);
        model.addAttribute("driverCount", driverCount);
        model.addAttribute("bookingCount", bookingCount);
        model.addAttribute("recentBookings", recentBookings);
        
        return "admin_dashboard";
    }

    @PostMapping("/admin/deleteUser")
    public String deleteUser(@RequestParam Integer id, HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }
        userRepository.deleteById(id);
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/admin/deleteDriver")
    public String deleteDriver(@RequestParam Integer id, HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }
        driverRepository.deleteById(id);
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/admin/editUser/{id}")
    public String editUser(@org.springframework.web.bind.annotation.PathVariable("id") Integer id,
                           Model model,
                           HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }
        var userOpt = userRepository.findById(id);
        if (userOpt.isEmpty()) {
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("user", userOpt.get());
        return "edit_user";
    }

    @PostMapping("/admin/updateUser")
    public String updateUser(@RequestParam Integer id,
                             @RequestParam String username,
                             @RequestParam String email,
                             @RequestParam String phoneNumber,
                             @RequestParam String role,
                             HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }
        var userOpt = userRepository.findById(id);
        if (userOpt.isPresent()) {
            var u = userOpt.get();
            u.setUsername(username);
            u.setEmail(email);
            u.setPhoneNumber(phoneNumber);
            u.setRole(role);
            userRepository.save(u);
        }
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/admin/editDriver/{id}")
    public String editDriver(@org.springframework.web.bind.annotation.PathVariable("id") Integer id,
                             Model model,
                             HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }
        var driverOpt = driverRepository.findById(id);
        if (driverOpt.isEmpty()) {
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("driver", driverOpt.get());
        return "edit_driver";
    }

    @PostMapping("/admin/updateDriver")
    public String updateDriver(@RequestParam Integer id,
                               @RequestParam String username,
                               @RequestParam String email,
                               @RequestParam String phoneNumber,
                               @RequestParam String licenseNumber,
                               HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }
        var driverOpt = driverRepository.findById(id);
        if (driverOpt.isPresent()) {
            var d = driverOpt.get();
            d.setUsername(username);
            d.setEmail(email);
            d.setPhoneNumber(phoneNumber);
            d.setLicenseNumber(licenseNumber);
            driverRepository.save(d);
        }
        return "redirect:/admin/dashboard";
    }
} 