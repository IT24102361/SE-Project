package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.SupportTicket;
import com.example.finalcarrentalsite.entity.TicketStatus;
import com.example.finalcarrentalsite.repository.SupportTicketRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/support")
public class SupportTicketAdminController {

    @Autowired
    private SupportTicketRepository supportTicketRepository;

    private boolean hasAccess(HttpSession session) {
        Object role = session.getAttribute("role");
        return role != null && ("ADMIN".equals(role) || "DRIVER".equals(role));
    }

    @GetMapping("/tickets")
    public String listAll(@RequestParam(value = "status", required = false) String status,
                          HttpSession session, Model model) {
        if (!hasAccess(session)) return "redirect:/user/login";
        List<SupportTicket> out;
        if (status != null) {
            out = supportTicketRepository.findByStatusOrderByCreatedAtDesc(TicketStatus.valueOf(status));
        } else {
            out = supportTicketRepository.findAll();
            out.sort((a,b) -> b.getCreatedAt().compareTo(a.getCreatedAt()));
        }
        model.addAttribute("tickets", out);
        model.addAttribute("status", status);
        return "support_tickets";
    }

    @GetMapping("/tickets/{id}")
    public String view(@PathVariable Integer id, HttpSession session, Model model) {
        if (!hasAccess(session)) return "redirect:/user/login";
        Optional<SupportTicket> opt = supportTicketRepository.findById(id);
        if (opt.isEmpty()) return "redirect:/support/tickets";
        model.addAttribute("ticket", opt.get());
        return "support_ticket_view";
    }

    @PostMapping("/tickets/{id}/status")
    public String updateStatus(@PathVariable Integer id, @RequestParam String status, HttpSession session) {
        if (!hasAccess(session)) return "redirect:/user/login";
        Optional<SupportTicket> opt = supportTicketRepository.findById(id);
        if (opt.isPresent()) {
            SupportTicket t = opt.get();
            t.setStatus(TicketStatus.valueOf(status));
            supportTicketRepository.save(t);
        }
        return "redirect:/support/tickets/" + id;
    }
}


