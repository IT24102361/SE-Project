package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.SupportTicket;
import com.example.finalcarrentalsite.entity.TicketComment;
import com.example.finalcarrentalsite.entity.TicketStatus;
import com.example.finalcarrentalsite.repository.SupportTicketRepository;
import com.example.finalcarrentalsite.repository.TicketCommentRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/tickets")
public class TicketController {

    @Autowired
    private SupportTicketRepository supportTicketRepository;

    @Autowired
    private TicketCommentRepository ticketCommentRepository;

    @GetMapping
    public String listMyTickets(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/user/login";
        List<SupportTicket> tickets = supportTicketRepository.findByCreatedByUsernameOrderByCreatedAtDesc(username);
        model.addAttribute("tickets", tickets);
        return "ticket_list";
    }

    @GetMapping("/new")
    public String showCreate(@RequestParam(value = "bookingId", required = false) Integer bookingId, HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/user/login";
        model.addAttribute("bookingId", bookingId);
        return "ticket_create";
    }

    @PostMapping
    public String create(@RequestParam String subject,
                         @RequestParam String description,
                         @RequestParam(value = "bookingId", required = false) Integer bookingId,
                         HttpSession session,
                         RedirectAttributes redirectAttributes) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/user/login";
        SupportTicket t = new SupportTicket();
        t.setSubject(subject);
        t.setDescription(description);
        t.setCreatedByUsername(username);
        t.setBookingId(bookingId);
        t.setStatus(TicketStatus.OPEN);
        supportTicketRepository.save(t);
        redirectAttributes.addFlashAttribute("message", "Ticket created");
        return "redirect:/tickets";
    }

    @GetMapping("/{id}")
    public String view(@PathVariable Integer id, HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/user/login";
        Optional<SupportTicket> opt = supportTicketRepository.findById(id);
        if (opt.isEmpty()) return "redirect:/tickets";
        SupportTicket ticket = opt.get();
        List<TicketComment> comments = ticketCommentRepository.findByTicketOrderByCreatedAtAsc(ticket);
        model.addAttribute("ticket", ticket);
        model.addAttribute("comments", comments);
        return "ticket_view";
    }

    @PostMapping("/{id}/comment")
    public String comment(@PathVariable Integer id, @RequestParam String content, HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/user/login";
        Optional<SupportTicket> opt = supportTicketRepository.findById(id);
        if (opt.isEmpty()) return "redirect:/tickets";
        TicketComment c = new TicketComment();
        c.setTicket(opt.get());
        c.setAuthorUsername(username);
        c.setContent(content);
        ticketCommentRepository.save(c);
        return "redirect:/tickets/" + id;
    }

    @PostMapping("/{id}/close")
    public String close(@PathVariable Integer id, HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/user/login";
        Optional<SupportTicket> opt = supportTicketRepository.findById(id);
        if (opt.isPresent()) {
            SupportTicket t = opt.get();
            t.setStatus(TicketStatus.CLOSED);
            supportTicketRepository.save(t);
        }
        return "redirect:/tickets/" + id;
    }
}


