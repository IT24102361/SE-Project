package com.example.finalcarrentalsite.repository;

import com.example.finalcarrentalsite.entity.SupportTicket;
import com.example.finalcarrentalsite.entity.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SupportTicketRepository extends JpaRepository<SupportTicket, Integer> {
    List<SupportTicket> findByCreatedByUsernameOrderByCreatedAtDesc(String username);
    List<SupportTicket> findByStatusOrderByCreatedAtDesc(TicketStatus status);
}


