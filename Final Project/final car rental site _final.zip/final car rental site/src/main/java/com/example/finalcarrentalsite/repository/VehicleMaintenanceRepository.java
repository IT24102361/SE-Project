package com.example.finalcarrentalsite.repository;

import com.example.finalcarrentalsite.entity.VehicleMaintenance;
import com.example.finalcarrentalsite.entity.Car;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface VehicleMaintenanceRepository extends JpaRepository<VehicleMaintenance, Integer> {
    
    // Find maintenance records for a specific car
    List<VehicleMaintenance> findByCarOrderByScheduledDateDesc(Car car);
    
    // Find maintenance records by car ID
    List<VehicleMaintenance> findByCar_CarIdOrderByScheduledDateDesc(int carId);
    
    // Find maintenance records by status
    List<VehicleMaintenance> findByStatusOrderByScheduledDateDesc(String status);
    
    // Find maintenance records by type
    List<VehicleMaintenance> findByMaintenanceTypeOrderByScheduledDateDesc(String maintenanceType);
    
    // Find maintenance records scheduled for today
    List<VehicleMaintenance> findByScheduledDateAndStatus(LocalDate date, String status);
    
    // Find overdue maintenance records
    @Query("SELECT vm FROM VehicleMaintenance vm WHERE vm.scheduledDate < :today AND vm.status IN ('SCHEDULED', 'IN_PROGRESS')")
    List<VehicleMaintenance> findOverdueMaintenance(LocalDate today);
    
    // Find maintenance records with feedback
    @Query("SELECT vm FROM VehicleMaintenance vm WHERE vm.feedback IS NOT NULL AND vm.feedback != ''")
    List<VehicleMaintenance> findMaintenanceWithFeedback();
    
    // Find maintenance records by date range
    List<VehicleMaintenance> findByScheduledDateBetweenOrderByScheduledDateDesc(LocalDate startDate, LocalDate endDate);
    
    // Find completed maintenance records for cost analysis
    List<VehicleMaintenance> findByStatusAndCompletionDateBetweenOrderByCompletionDateDesc(String status, LocalDate startDate, LocalDate endDate);
}
