package com.example.finalcarrentalsite.service;

import com.example.finalcarrentalsite.entity.Promotion;
import com.example.finalcarrentalsite.repository.PromotionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PromotionService {
    
    @Autowired
    private PromotionRepository promotionRepository;
    
    // Create a new promotion
    public Promotion createPromotion(Promotion promotion) {
        promotion.setCreatedAt(LocalDateTime.now());
        promotion.setUpdatedAt(LocalDateTime.now());
        return promotionRepository.save(promotion);
    }
    
    // Update an existing promotion
    public Promotion updatePromotion(Promotion promotion) {
        promotion.setUpdatedAt(LocalDateTime.now());
        return promotionRepository.save(promotion);
    }
    
    // Get all active promotions
    public List<Promotion> getAllActivePromotions() {
        return promotionRepository.findByIsActiveTrue();
    }
    
    // Get all promotions (active and inactive)
    public List<Promotion> getAllPromotions() {
        return promotionRepository.findAll();
    }
    
    // Get promotion by ID
    public Optional<Promotion> getPromotionById(int promotionId) {
        return promotionRepository.findById(promotionId);
    }
    
    // Get active promotions for a specific date
    public List<Promotion> getActivePromotionsForDate(LocalDate date) {
        return promotionRepository.findActivePromotionsOnDate(date);
    }
    
    // Get active promotions for today
    public List<Promotion> getActivePromotionsForToday() {
        return getActivePromotionsForDate(LocalDate.now());
    }
    
    // Get promotion by code
    public Optional<Promotion> getPromotionByCode(String promotionCode) {
        return promotionRepository.findByPromotionCodeAndIsActiveTrue(promotionCode);
    }
    
    // Calculate discount for a booking
    public double calculateDiscountForBooking(double originalPrice, LocalDate bookingDate, String promotionCode) {
        List<Promotion> activePromotions = getActivePromotionsForDate(bookingDate);
        
        // If a specific promotion code is provided, use that
        if (promotionCode != null && !promotionCode.trim().isEmpty()) {
            Optional<Promotion> specificPromotion = getPromotionByCode(promotionCode);
            if (specificPromotion.isPresent() && specificPromotion.get().isCurrentlyActive()) {
                return specificPromotion.get().calculateDiscount(originalPrice);
            }
        }
        
        // Otherwise, find the best applicable promotion
        double maxDiscount = 0.0;
        for (Promotion promotion : activePromotions) {
            double discount = promotion.calculateDiscount(originalPrice);
            maxDiscount = Math.max(maxDiscount, discount);
        }
        
        return maxDiscount;
    }
    
    // Get weekend promotions
    public List<Promotion> getWeekendPromotions() {
        return promotionRepository.findWeekendPromotions();
    }
    
    // Get holiday promotions
    public List<Promotion> getHolidayPromotions() {
        return promotionRepository.findHolidayPromotions();
    }
    
    // Get promotions ending soon
    public List<Promotion> getPromotionsEndingSoon() {
        LocalDate today = LocalDate.now();
        LocalDate nextWeek = today.plusDays(7);
        return promotionRepository.findPromotionsEndingSoon(today, nextWeek);
    }
    
    // Get promotions starting soon
    public List<Promotion> getPromotionsStartingSoon() {
        LocalDate today = LocalDate.now();
        LocalDate nextWeek = today.plusDays(7);
        return promotionRepository.findPromotionsStartingSoon(today, nextWeek);
    }
    
    // Get expired promotions
    public List<Promotion> getExpiredPromotions() {
        return promotionRepository.findExpiredPromotions(LocalDate.now());
    }
    
    // Deactivate a promotion
    public void deactivatePromotion(int promotionId) {
        Optional<Promotion> promotion = promotionRepository.findById(promotionId);
        if (promotion.isPresent()) {
            promotion.get().setIsActive(false);
            promotion.get().setUpdatedAt(LocalDateTime.now());
            promotionRepository.save(promotion.get());
        }
    }
    
    // Activate a promotion
    public void activatePromotion(int promotionId) {
        Optional<Promotion> promotion = promotionRepository.findById(promotionId);
        if (promotion.isPresent()) {
            promotion.get().setIsActive(true);
            promotion.get().setUpdatedAt(LocalDateTime.now());
            promotionRepository.save(promotion.get());
        }
    }
    
    // Delete a promotion
    public void deletePromotion(int promotionId) {
        promotionRepository.deleteById(promotionId);
    }
    
    // Search promotions by name
    public List<Promotion> searchPromotionsByName(String promotionName) {
        return promotionRepository.findByPromotionNameContainingIgnoreCaseAndIsActiveTrue(promotionName);
    }
    
    // Create a weekend promotion
    public Promotion createWeekendPromotion(String promotionName, String description, 
                                          double discountPercentage, LocalDate startDate, LocalDate endDate) {
        Promotion promotion = new Promotion(promotionName, description, discountPercentage, startDate, endDate);
        promotion.setPromotionCode("WEEKEND" + System.currentTimeMillis());
        return createPromotion(promotion);
    }
    
    // Create a holiday promotion
    public Promotion createHolidayPromotion(String promotionName, String description, 
                                          double discountPercentage, LocalDate startDate, LocalDate endDate) {
        Promotion promotion = new Promotion(promotionName, description, discountPercentage, startDate, endDate);
        promotion.setPromotionCode("HOLIDAY" + System.currentTimeMillis());
        return createPromotion(promotion);
    }
    
    // Check if a date falls on weekend
    public boolean isWeekend(LocalDate date) {
        return date.getDayOfWeek().getValue() >= 6; // Saturday = 6, Sunday = 7
    }
    
    // Get the best promotion for a given date and price
    public Optional<Promotion> getBestPromotionForDate(LocalDate date, double price) {
        List<Promotion> activePromotions = getActivePromotionsForDate(date);
        
        return activePromotions.stream()
                .max((p1, p2) -> Double.compare(
                    p1.calculateDiscount(price), 
                    p2.calculateDiscount(price)
                ));
    }
}
