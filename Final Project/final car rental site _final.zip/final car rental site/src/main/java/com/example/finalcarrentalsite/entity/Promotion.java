package com.example.finalcarrentalsite.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "Promotion")
public class Promotion {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int promotionId;
    
    private String promotionName;
    private String description;
    private double discountPercentage;
    private double discountAmount;
    private String discountType; // PERCENTAGE or FIXED_AMOUNT
    private LocalDate startDate;
    private LocalDate endDate;
    private boolean isActive;
    private String promotionCode; // Optional promo code
    private String conditions; // Additional conditions like minimum rental days
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    // Promotion types
    public static final String WEEKEND_PROMOTION = "WEEKEND";
    public static final String HOLIDAY_PROMOTION = "HOLIDAY";
    public static final String SPECIAL_EVENT = "SPECIAL_EVENT";
    public static final String GENERAL_PROMOTION = "GENERAL";
    
    // Discount types
    public static final String PERCENTAGE = "PERCENTAGE";
    public static final String FIXED_AMOUNT = "FIXED_AMOUNT";
    
    // Constructors
    public Promotion() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.isActive = true;
    }
    
    public Promotion(String promotionName, String description, double discountPercentage, 
                    LocalDate startDate, LocalDate endDate) {
        this();
        this.promotionName = promotionName;
        this.description = description;
        this.discountPercentage = discountPercentage;
        this.discountType = PERCENTAGE;
        this.startDate = startDate;
        this.endDate = endDate;
    }
    
    // Getters and Setters
    public int getPromotionId() { return promotionId; }
    public void setPromotionId(int promotionId) { this.promotionId = promotionId; }
    
    public String getPromotionName() { return promotionName; }
    public void setPromotionName(String promotionName) { this.promotionName = promotionName; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public double getDiscountPercentage() { return discountPercentage; }
    public void setDiscountPercentage(double discountPercentage) { this.discountPercentage = discountPercentage; }
    
    public double getDiscountAmount() { return discountAmount; }
    public void setDiscountAmount(double discountAmount) { this.discountAmount = discountAmount; }
    
    public String getDiscountType() { return discountType; }
    public void setDiscountType(String discountType) { this.discountType = discountType; }
    
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public boolean getIsActive() {
        return isActive;
    }
    public void setIsActive(boolean active) {
        this.isActive = active;
    }
    
    public String getPromotionCode() { return promotionCode; }
    public void setPromotionCode(String promotionCode) { this.promotionCode = promotionCode; }
    
    public String getConditions() { return conditions; }
    public void setConditions(String conditions) { this.conditions = conditions; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    
    // Helper methods
    public boolean isCurrentlyActive() {
        LocalDate today = LocalDate.now();
        return isActive && !today.isBefore(startDate) && !today.isAfter(endDate);
    }
    
    public double calculateDiscount(double originalPrice) {
        if (!isCurrentlyActive()) {
            return 0.0;
        }
        
        if (PERCENTAGE.equals(discountType)) {
            return originalPrice * (discountPercentage / 100.0);
        } else if (FIXED_AMOUNT.equals(discountType)) {
            return Math.min(discountAmount, originalPrice);
        }
        
        return 0.0;
    }
    
    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
