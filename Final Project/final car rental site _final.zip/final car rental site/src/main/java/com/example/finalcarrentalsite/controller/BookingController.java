package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.Booking;
import com.example.finalcarrentalsite.entity.Car;
import com.example.finalcarrentalsite.entity.Driver;
import com.example.finalcarrentalsite.entity.user;
import com.example.finalcarrentalsite.entity.Promotion;
import com.example.finalcarrentalsite.repository.BookingRepository;
import com.example.finalcarrentalsite.repository.CarRepository;
import com.example.finalcarrentalsite.repository.DriverRepository;
import com.example.finalcarrentalsite.repository.UserRepository;
import com.example.finalcarrentalsite.service.EmailService;
import com.example.finalcarrentalsite.service.PromotionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private PromotionService promotionService;
    

    // Helper method for price calculation
    private double calculateTotalPrice(Car car, LocalDate pickup, LocalDate dropoff) {
        long days = ChronoUnit.DAYS.between(pickup, dropoff);
        if (days <= 0) {
            return -1; // invalid booking
        }
        return days * car.getPricePerDay();
    }

    // Show booking form
    @GetMapping("/form/{carId}")
    public String showBookingForm(@PathVariable("carId") Integer carId,
                                  Model model,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/user/login"; // Redirect to user login instead of driver
        }

        Optional<Car> carOpt = carRepository.findById(carId);
        if (carOpt.isEmpty()) {
            return "redirect:/cars";
        }

        Car car = carOpt.get();
        
        // Check if car is available for booking
        if (!"AVAILABLE".equals(car.getMaintenanceStatus())) {
            redirectAttributes.addFlashAttribute("error", "This vehicle is currently under maintenance and cannot be booked.");
            return "redirect:/cars";
        }

        // Get active promotions for today
        List<Promotion> activePromotions = promotionService.getActivePromotionsForToday();
        
        model.addAttribute("car", carOpt.get());
        model.addAttribute("activePromotions", activePromotions);
        return "booking-form";
    }

    // Create booking
    @PostMapping("/create/{carId}")
    public String createBooking(@PathVariable("carId") Integer carId,
                                @RequestParam("pickupDate") String pickupDate,
                                @RequestParam("dropoffDate") String dropoffDate,
                                @RequestParam(value = "pickupTime", required = false) String pickupTime,
                                @RequestParam(value = "dropoffTime", required = false) String dropoffTime,
                                @RequestParam(value = "pickupLocation", required = false) String pickupLocation,
                                @RequestParam(value = "dropoffLocation", required = false) String dropoffLocation,
                                @RequestParam(value = "specialRequests", required = false) String specialRequests,
                                @RequestParam(value = "paymentMethod", required = false) String paymentMethod,
                                @RequestParam(value = "cardNumber", required = false) String cardNumber,
                                @RequestParam(value = "expiryDate", required = false) String expiryDate,
                                @RequestParam(value = "cvv", required = false) String cvv,
                                @RequestParam(value = "cardholderName", required = false) String cardholderName,
                                @RequestParam(value = "promotionCode", required = false) String promotionCode,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {

        System.out.println("DEBUG: createBooking method called for carId: " + carId);
        
        String username = (String) session.getAttribute("username");
        String userRole = (String) session.getAttribute("role");
        
        if (username == null) {
            redirectAttributes.addFlashAttribute("error", "Please log in first.");
            return "redirect:/user/login";
        }

        Optional<Car> carOpt = carRepository.findById(carId);
        
        // Check if user is a driver or regular user
        Driver driver = null;
        user regularUser = null;
        
        if ("DRIVER".equals(userRole)) {
            List<Driver> drivers = driverRepository.findAllByUsername(username);
            driver = drivers.isEmpty() ? null : drivers.get(0);
        } else {
            regularUser = userRepository.findByUsername(username).orElse(null);
        }

        System.out.println("DEBUG: Car found: " + carOpt.isPresent());
        System.out.println("DEBUG: Driver found: " + (driver != null));
        System.out.println("DEBUG: User found: " + (regularUser != null));
        System.out.println("DEBUG: User role: " + userRole);

        if (carOpt.isEmpty() || (driver == null && regularUser == null)) {
            redirectAttributes.addFlashAttribute("error", "Car or User not found.");
            return "redirect:/cars";
        }

        Car car = carOpt.get();
        
        // Check if car is available for booking
        if (!"AVAILABLE".equals(car.getMaintenanceStatus())) {
            redirectAttributes.addFlashAttribute("error", "This vehicle is currently under maintenance and cannot be booked.");
            return "redirect:/cars";
        }

        LocalDate pickup = LocalDate.parse(pickupDate);
        LocalDate dropoff = LocalDate.parse(dropoffDate);

        // Calculate base total price
        double basePrice = calculateTotalPrice(car, pickup, dropoff);
        if (basePrice <= 0) {
            redirectAttributes.addFlashAttribute("error", "Invalid booking dates. Please ensure dropoff date is after pickup date.");
            return "redirect:/bookings/form/" + carId;
        }
        
        // Check for maximum rental period (30 days)
        long days = ChronoUnit.DAYS.between(pickup, dropoff);
        if (days > 30) {
            redirectAttributes.addFlashAttribute("error", "Maximum rental period is 30 days.");
            return "redirect:/bookings/form/" + carId;
        }

        // Calculate discount from promotions
        double discount = promotionService.calculateDiscountForBooking(basePrice, pickup, promotionCode);
        double totalPrice = basePrice - discount;
        
        // Ensure total price is not negative
        if (totalPrice < 0) {
            totalPrice = 0;
        }

        Booking booking = new Booking();
        booking.setCar(car);
        
        // Set the driver field based on user type
        if (driver != null) {
            booking.setDriver(driver);
        } else {
            // For regular users, reuse an existing driver by username if present; else create one
            List<Driver> drivers = driverRepository.findAllByUsername(regularUser.getUsername());
            Driver useDriver;
            if (!drivers.isEmpty()) {
                useDriver = drivers.get(0);
            } else {
                Driver tempDriver = new Driver();
                tempDriver.setUsername(regularUser.getUsername());
                tempDriver.setEmail(regularUser.getEmail());
                tempDriver.setPhoneNumber(regularUser.getPhoneNumber());
                tempDriver.setRole("USER");
                tempDriver.setPassword(""); // Set empty password for temporary driver
                tempDriver.setLicenseNumber(""); // Set empty license for temporary driver
                useDriver = driverRepository.save(tempDriver);
                System.out.println("DEBUG: Created new driver with ID: " + useDriver.getId() + " for username: " + useDriver.getUsername());
            }
            booking.setDriver(useDriver);
        }
        
        booking.setPickupDate(pickup);
        booking.setDropoffDate(dropoff);
        booking.setTotalPrice(totalPrice);
        booking.setStripeSessionId(null);

        String chosenMethod = (paymentMethod == null || paymentMethod.isBlank()) ? "COD" : paymentMethod;
        String recipient = driver != null ? driver.getEmail() : (regularUser != null ? regularUser.getEmail() : null);
        
        // Store discount information in session for display
        if (discount > 0) {
            session.setAttribute("lastDiscount", discount);
            session.setAttribute("lastPromotionCode", promotionCode);
        }
        
        if ("COD".equalsIgnoreCase(chosenMethod)) {
            try {
                booking.setPaymentStatus("PENDING");
                System.out.println("DEBUG: Saving booking with driver ID: " + booking.getDriver().getId());
                System.out.println("DEBUG: Booking details - Car: " + booking.getCar().getCarId() + 
                    ", Driver: " + booking.getDriver().getUsername() + 
                    ", Dates: " + booking.getPickupDate() + " to " + booking.getDropoffDate() +
                    ", Price: " + booking.getTotalPrice());
                Booking saved = bookingRepository.save(booking);
                System.out.println("DEBUG: Booking saved with ID: " + saved.getBookingId());
                
                // Send email with promotion details
                if (discount > 0) {
                    System.out.println("DEBUG: Sending email with discount: " + discount);
                    emailService.sendBookingConfirmation(recipient, saved, discount, promotionCode);
                } else {
                    System.out.println("DEBUG: Sending email without discount");
                    emailService.sendBookingConfirmation(recipient, saved);
                }
                
                String message = "COD booking confirmed. Check your email for receipt.";
                if (discount > 0) {
                    message += " You saved $" + String.format("%.2f", discount) + " with promotion!";
                }
                redirectAttributes.addFlashAttribute("message", message);
                System.out.println("DEBUG: Redirecting to /bookings/my after COD booking");
                return "redirect:/bookings/my";
            } catch (Exception e) {
                System.out.println("DEBUG: Error saving booking: " + e.getMessage());
                e.printStackTrace();
                redirectAttributes.addFlashAttribute("error", "Failed to save booking. Please try again.");
                return "redirect:/bookings/form/" + carId;
            }
        } else {
            booking.setPaymentStatus("PENDING");
            System.out.println("DEBUG: Saving booking for non-COD payment with driver ID: " + booking.getDriver().getId());
            Booking saved = bookingRepository.save(booking);
            System.out.println("DEBUG: Booking saved with ID: " + saved.getBookingId() + ", redirecting to payment page");
            return "redirect:/bookings/pay/" + saved.getBookingId();
        }
    }

    // Show bookings for logged-in user (both drivers and regular users)
    @GetMapping("/my")
    public String myBookings(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        String userRole = (String) session.getAttribute("role");
        
        System.out.println("DEBUG: myBookings called for username: " + username + ", role: " + userRole);
        System.out.println("DEBUG: Session attributes: " + session.getAttributeNames());
        
        if (username == null) {
            System.out.println("DEBUG: No username in session, redirecting to login");
            return "redirect:/user/login";
        }

        try {
            Driver driver = null;
            if ("DRIVER".equals(userRole)) {
                List<Driver> drivers = driverRepository.findAllByUsername(username);
                driver = drivers.isEmpty() ? null : drivers.get(0);
                System.out.println("DEBUG: DRIVER role - Found driver: " + (driver != null ? driver.getId() : "null"));
            } else {
                // For regular users, find their driver record (by username; there may be multiple)
                List<Driver> drivers = driverRepository.findAllByUsername(username);
                driver = drivers.isEmpty() ? null : drivers.get(0);
                System.out.println("DEBUG: USER role - Found driver: " + (driver != null ? driver.getId() : "null"));
            }

            List<Booking> myBookings = java.util.Collections.emptyList();
            if (driver != null && driver.getId() != null) {
                myBookings = bookingRepository.findByDriver_Id(driver.getId());
                System.out.println("DEBUG: Found " + myBookings.size() + " bookings by driver ID: " + driver.getId());
            } else {
                // Fall back to username-based search (covers USER-created temporary driver records)
                myBookings = bookingRepository.findByDriver_Username(username);
                System.out.println("DEBUG: Found " + myBookings.size() + " bookings by username: " + username);
            }
            
            // Additional debugging
            System.out.println("DEBUG: Total bookings found: " + myBookings.size());
            for (Booking booking : myBookings) {
                System.out.println("DEBUG: Booking ID: " + booking.getBookingId() + ", Driver: " + 
                    (booking.getDriver() != null ? booking.getDriver().getUsername() : "null"));
            }
            
            model.addAttribute("bookings", myBookings);
        } catch (Exception ex) {
            System.out.println("DEBUG: Exception in myBookings: " + ex.getMessage());
            ex.printStackTrace();
            model.addAttribute("bookings", java.util.Collections.emptyList());
            model.addAttribute("error", "Could not load bookings: " + ex.getMessage());
        }
        return "my-bookings";
    }

    @GetMapping("/pay/{id}")
    public String showPayment(@PathVariable("id") Integer bookingId, HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/user/login";

        Optional<Booking> bookingOpt = bookingRepository.findById(bookingId);
        if (bookingOpt.isEmpty()) return "redirect:/bookings/my";

        Booking booking = bookingOpt.get();

        // 💡 1. Calculate the number of rental days
        // Ensure pickupDate and dropoffDate are non-null LocalDates
        long rentalDays = ChronoUnit.DAYS.between(booking.getPickupDate(), booking.getDropoffDate());

        model.addAttribute("booking", booking);
        // 💡 2. Add the calculated days to the model
        model.addAttribute("rentalDays", rentalDays);

        return "payment";
    }

    @PostMapping("/pay/{id}")
    public String processPayment(@PathVariable("id") Integer bookingId, 
                               @RequestParam("receiptEmail") String receiptEmail,
                               @RequestParam("paymentMethod") String paymentMethod,
                               @RequestParam(value = "cardNumber", required = false) String cardNumber,
                               @RequestParam(value = "expiryDate", required = false) String expiryDate,
                               @RequestParam(value = "cvv", required = false) String cvv,
                               @RequestParam(value = "cardholderName", required = false) String cardholderName,
                               @RequestParam("terms") String terms,
                               HttpSession session, 
                               RedirectAttributes redirectAttributes) {
        
        System.out.println("DEBUG: Payment processing started for booking ID: " + bookingId);
        System.out.println("DEBUG: Payment method: " + paymentMethod);
        System.out.println("DEBUG: Receipt email: " + receiptEmail);
        
        String username = (String) session.getAttribute("username");
        if (username == null) return "redirect:/user/login";
        
        Optional<Booking> bookingOpt = bookingRepository.findById(bookingId);
        if (bookingOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Booking not found.");
            return "redirect:/bookings/my";
        }
        
        Booking booking = bookingOpt.get();
        
        try {
            // Validate receipt email
            if (receiptEmail == null || receiptEmail.trim().isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "Please provide an email address for receipt.");
                return "redirect:/bookings/pay/" + bookingId;
            }
            
            // Basic email validation
            if (!receiptEmail.contains("@") || !receiptEmail.contains(".")) {
                redirectAttributes.addFlashAttribute("error", "Please provide a valid email address.");
                return "redirect:/bookings/pay/" + bookingId;
            }
            
            // Validate payment method specific data
            if ("card".equals(paymentMethod)) {
                if (cardNumber == null || cardNumber.trim().isEmpty() ||
                    expiryDate == null || expiryDate.trim().isEmpty() ||
                    cvv == null || cvv.trim().isEmpty() ||
                    cardholderName == null || cardholderName.trim().isEmpty()) {
                    redirectAttributes.addFlashAttribute("error", "Please fill in all card details.");
                    return "redirect:/bookings/pay/" + bookingId;
                }
                
                // Simulate card validation (in real app, integrate with payment gateway)
                if (!isValidCardNumber(cardNumber)) {
                    redirectAttributes.addFlashAttribute("error", "Invalid card number.");
                    return "redirect:/bookings/pay/" + bookingId;
                }
                
                // Validate expiry date format
                if (!expiryDate.matches("\\d{2}/\\d{2}")) {
                    redirectAttributes.addFlashAttribute("error", "Invalid expiry date format. Use MM/YY.");
                    return "redirect:/bookings/pay/" + bookingId;
                }
                
                // Validate CVV
                if (cvv.length() < 3 || cvv.length() > 4 || !cvv.matches("\\d+")) {
                    redirectAttributes.addFlashAttribute("error", "Invalid CVV.");
                    return "redirect:/bookings/pay/" + bookingId;
                }
                
                System.out.println("DEBUG: Card payment validated successfully");
            }
            
            // Process payment based on method
            boolean paymentSuccess = processPaymentByMethod(paymentMethod, booking.getTotalPrice(), 
                                                         cardNumber, expiryDate, cvv, cardholderName);
            
            if (!paymentSuccess) {
                redirectAttributes.addFlashAttribute("error", "Payment failed. Please try again.");
                return "redirect:/bookings/pay/" + bookingId;
            }
            
            // Update booking status
            booking.setPaymentStatus("PAID");
            bookingRepository.save(booking);
            System.out.println("DEBUG: Booking payment status updated to PAID");
            
            // Send confirmation email to specified email
            String recipient = receiptEmail != null && !receiptEmail.trim().isEmpty() ? 
                             receiptEmail : (booking.getDriver() != null ? booking.getDriver().getEmail() : null);
            
            if (recipient != null) {
                System.out.println("DEBUG: Sending payment confirmation email to: " + recipient);
                emailService.sendBookingConfirmation(recipient, booking);
            } else {
                System.out.println("DEBUG: No email address available for receipt");
            }
            
            String successMessage = "Payment successful! Receipt sent to " + recipient;
            if ("card".equals(paymentMethod)) {
                successMessage += " (Card ending in " + cardNumber.substring(cardNumber.length() - 4) + ")";
            } else if ("paypal".equals(paymentMethod)) {
                successMessage += " (PayPal)";
            } else if ("bank".equals(paymentMethod)) {
                successMessage += " (Bank Transfer)";
            } else if ("cod".equals(paymentMethod)) {
                successMessage += " (Cash on Delivery)";
            }
            
            redirectAttributes.addFlashAttribute("message", successMessage);
            return "redirect:/bookings/my";
            
        } catch (Exception e) {
            System.out.println("DEBUG: Payment processing error: " + e.getMessage());
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "Payment processing failed. Please try again.");
            return "redirect:/bookings/pay/" + bookingId;
        }
    }
    
    // Helper method to validate card number (basic Luhn algorithm)
    private boolean isValidCardNumber(String cardNumber) {
        if (cardNumber == null || cardNumber.trim().isEmpty()) return false;
        
        // Remove spaces and non-digits
        String cleanNumber = cardNumber.replaceAll("\\s+", "").replaceAll("\\D", "");
        
        // Check if it's 13-19 digits
        if (cleanNumber.length() < 13 || cleanNumber.length() > 19) return false;
        
        // Basic Luhn algorithm validation
        int sum = 0;
        boolean alternate = false;
        for (int i = cleanNumber.length() - 1; i >= 0; i--) {
            int digit = Character.getNumericValue(cleanNumber.charAt(i));
            if (alternate) {
                digit *= 2;
                if (digit > 9) {
                    digit = (digit % 10) + 1;
                }
            }
            sum += digit;
            alternate = !alternate;
        }
        return (sum % 10) == 0;
    }
    
    // Helper method to process payment by method (simulated)
    private boolean processPaymentByMethod(String method, double amount, 
                                         String cardNumber, String expiryDate, 
                                         String cvv, String cardholderName) {
        System.out.println("DEBUG: Processing " + method + " payment for amount: $" + amount);
        
        // Simulate payment processing delay
        try {
            Thread.sleep(1000); // 1 second delay to simulate processing
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Simulate different success rates based on payment method
        switch (method.toLowerCase()) {
            case "card":
                // Simulate 95% success rate for card payments
                return Math.random() > 0.05;
            case "paypal":
                // Simulate 90% success rate for PayPal
                return Math.random() > 0.10;
            case "bank":
                // Simulate 98% success rate for bank transfers
                return Math.random() > 0.02;
            case "cod":
                // COD always succeeds
                return true;
            default:
                return false;
        }
    }

    // Simple test endpoint to verify basic functionality
    @GetMapping("/test")
    @ResponseBody
    public String testEndpoint() {
        return "Booking Controller is working! Time: " + java.time.LocalDateTime.now();
    }

    // Debug endpoint to check database state
    @GetMapping("/debug")
    @ResponseBody
    public String debugBookings(HttpSession session) {
        String username = (String) session.getAttribute("username");
        String userRole = (String) session.getAttribute("role");
        
        StringBuilder debug = new StringBuilder();
        debug.append("=== DEBUG INFO ===\n");
        debug.append("Username: ").append(username).append("\n");
        debug.append("Role: ").append(userRole).append("\n");
        
        if (username != null) {
            // Check drivers
            List<Driver> drivers = driverRepository.findAllByUsername(username);
            debug.append("Drivers found: ").append(drivers.size()).append("\n");
            for (Driver driver : drivers) {
                debug.append("  Driver ID: ").append(driver.getId()).append(", Username: ").append(driver.getUsername()).append("\n");
            }
            
            // Check bookings by driver ID
            if (!drivers.isEmpty()) {
                List<Booking> bookingsById = bookingRepository.findByDriver_Id(drivers.get(0).getId());
                debug.append("Bookings by driver ID: ").append(bookingsById.size()).append("\n");
                for (Booking booking : bookingsById) {
                    debug.append("  Booking ID: ").append(booking.getBookingId()).append(", Driver: ").append(booking.getDriver().getUsername()).append("\n");
                }
            }
            
            // Check bookings by username
            List<Booking> bookingsByUsername = bookingRepository.findByDriver_Username(username);
            debug.append("Bookings by username: ").append(bookingsByUsername.size()).append("\n");
            for (Booking booking : bookingsByUsername) {
                debug.append("  Booking ID: ").append(booking.getBookingId()).append(", Driver: ").append(booking.getDriver().getUsername()).append("\n");
            }
        }
        
        return debug.toString();
    }

    // API endpoint to calculate discount in real-time
    @GetMapping("/api/calculate-discount")
    @ResponseBody
    public double calculateDiscount(@RequestParam double price, 
                                  @RequestParam String date, 
                                  @RequestParam(required = false) String promotionCode) {
        LocalDate bookingDate = LocalDate.parse(date);
        return promotionService.calculateDiscountForBooking(price, bookingDate, promotionCode);
    }
}
