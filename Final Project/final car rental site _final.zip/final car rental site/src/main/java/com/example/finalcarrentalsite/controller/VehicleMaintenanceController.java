package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.VehicleMaintenance;
import com.example.finalcarrentalsite.entity.Car;
import com.example.finalcarrentalsite.repository.VehicleMaintenanceRepository;
import com.example.finalcarrentalsite.repository.CarRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin/maintenance")
public class VehicleMaintenanceController {

    @Autowired
    private VehicleMaintenanceRepository maintenanceRepository;

    @Autowired
    private CarRepository carRepository;

    @GetMapping("/dashboard")
    public String maintenanceDashboard(Model model, HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        // Get all cars with their maintenance status
        List<Car> cars = carRepository.findAll();
        
        // Get maintenance statistics
        long totalMaintenanceRecords = maintenanceRepository.count();
        List<VehicleMaintenance> scheduledMaintenance = maintenanceRepository.findByStatusOrderByScheduledDateDesc("SCHEDULED");
        List<VehicleMaintenance> inProgressMaintenance = maintenanceRepository.findByStatusOrderByScheduledDateDesc("IN_PROGRESS");
        List<VehicleMaintenance> overdueMaintenance = maintenanceRepository.findOverdueMaintenance(LocalDate.now());
        
        // Get cars needing attention
        List<Car> carsNeedingMaintenance = cars.stream()
            .filter(car -> "MAINTENANCE".equals(car.getMaintenanceStatus()) || "OUT_OF_SERVICE".equals(car.getMaintenanceStatus()))
            .toList();

        model.addAttribute("cars", cars);
        model.addAttribute("totalMaintenanceRecords", totalMaintenanceRecords);
        model.addAttribute("scheduledMaintenance", scheduledMaintenance);
        model.addAttribute("inProgressMaintenance", inProgressMaintenance);
        model.addAttribute("overdueMaintenance", overdueMaintenance);
        model.addAttribute("carsNeedingMaintenance", carsNeedingMaintenance);

        return "vehicle_maintenance_dashboard";
    }

    @GetMapping("/records")
    public String maintenanceRecords(Model model, HttpSession session,
                                   @RequestParam(required = false) String status,
                                   @RequestParam(required = false) String type) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        List<VehicleMaintenance> maintenanceRecords;
        
        if (status != null && !status.isEmpty()) {
            maintenanceRecords = maintenanceRepository.findByStatusOrderByScheduledDateDesc(status);
        } else if (type != null && !type.isEmpty()) {
            maintenanceRecords = maintenanceRepository.findByMaintenanceTypeOrderByScheduledDateDesc(type);
        } else {
            maintenanceRecords = maintenanceRepository.findAll();
        }

        model.addAttribute("maintenanceRecords", maintenanceRecords);
        model.addAttribute("selectedStatus", status);
        model.addAttribute("selectedType", type);

        return "maintenance_records";
    }

    @GetMapping("/add")
    public String showAddMaintenanceForm(Model model, HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        List<Car> cars = carRepository.findAll();
        model.addAttribute("cars", cars);
        model.addAttribute("maintenance", new VehicleMaintenance());

        return "add_maintenance";
    }

    @PostMapping("/add")
    public String addMaintenance(@ModelAttribute VehicleMaintenance maintenance,
                               @RequestParam int carId,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        Optional<Car> carOpt = carRepository.findById(carId);
        if (carOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Car not found.");
            return "redirect:/admin/maintenance/add";
        }

        Car car = carOpt.get();
        maintenance.setCar(car);
        
        // Set default status if not provided
        if (maintenance.getStatus() == null || maintenance.getStatus().isEmpty()) {
            maintenance.setStatus("SCHEDULED");
        }

        maintenanceRepository.save(maintenance);

        // Update car maintenance status
        car.setMaintenanceStatus("MAINTENANCE");
        carRepository.save(car);

        redirectAttributes.addFlashAttribute("message", "Maintenance record added successfully.");
        return "redirect:/admin/maintenance/records";
    }

    @GetMapping("/edit/{id}")
    public String showEditMaintenanceForm(@PathVariable int id, Model model, HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        Optional<VehicleMaintenance> maintenanceOpt = maintenanceRepository.findById(id);
        if (maintenanceOpt.isEmpty()) {
            return "redirect:/admin/maintenance/records";
        }

        List<Car> cars = carRepository.findAll();
        model.addAttribute("cars", cars);
        model.addAttribute("maintenance", maintenanceOpt.get());

        return "edit_maintenance";
    }

    @PostMapping("/update")
    public String updateMaintenance(@ModelAttribute VehicleMaintenance maintenance,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        Optional<VehicleMaintenance> existingOpt = maintenanceRepository.findById(maintenance.getMaintenanceId());
        if (existingOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Maintenance record not found.");
            return "redirect:/admin/maintenance/records";
        }

        VehicleMaintenance existing = existingOpt.get();
        Car car = existing.getCar();

        // Update maintenance record
        existing.setMaintenanceType(maintenance.getMaintenanceType());
        existing.setDescription(maintenance.getDescription());
        existing.setStatus(maintenance.getStatus());
        existing.setScheduledDate(maintenance.getScheduledDate());
        existing.setCompletionDate(maintenance.getCompletionDate());
        existing.setEstimatedCost(maintenance.getEstimatedCost());
        existing.setActualCost(maintenance.getActualCost());
        existing.setMechanic(maintenance.getMechanic());
        existing.setNotes(maintenance.getNotes());
        existing.setFeedback(maintenance.getFeedback());

        maintenanceRepository.save(existing);

        // Update car status based on maintenance status
        if ("COMPLETED".equals(maintenance.getStatus())) {
            car.setMaintenanceStatus("AVAILABLE");
            car.setAvailabilityStatus("AVAILABLE");
        } else if ("IN_PROGRESS".equals(maintenance.getStatus())) {
            car.setMaintenanceStatus("MAINTENANCE");
            car.setAvailabilityStatus("MAINTENANCE");
        }

        carRepository.save(car);

        redirectAttributes.addFlashAttribute("message", "Maintenance record updated successfully.");
        return "redirect:/admin/maintenance/records";
    }

    @PostMapping("/delete/{id}")
    public String deleteMaintenance(@PathVariable int id, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        Optional<VehicleMaintenance> maintenanceOpt = maintenanceRepository.findById(id);
        if (maintenanceOpt.isPresent()) {
            VehicleMaintenance maintenance = maintenanceOpt.get();
            Car car = maintenance.getCar();
            
            // Update car status if it was in maintenance
            if ("MAINTENANCE".equals(car.getMaintenanceStatus()) || "OUT_OF_SERVICE".equals(car.getMaintenanceStatus())) {
                car.setMaintenanceStatus("AVAILABLE");
                car.setAvailabilityStatus("AVAILABLE");
                carRepository.save(car);
            }
            
            maintenanceRepository.deleteById(id);
            redirectAttributes.addFlashAttribute("message", "Maintenance record deleted successfully.");
        } else {
            redirectAttributes.addFlashAttribute("error", "Maintenance record not found.");
        }

        return "redirect:/admin/maintenance/records";
    }

    @GetMapping("/car/{carId}")
    public String carMaintenanceHistory(@PathVariable int carId, Model model, HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        Optional<Car> carOpt = carRepository.findById(carId);
        if (carOpt.isEmpty()) {
            return "redirect:/admin/maintenance/dashboard";
        }

        Car car = carOpt.get();
        List<VehicleMaintenance> maintenanceHistory = maintenanceRepository.findByCar_CarIdOrderByScheduledDateDesc(carId);

        model.addAttribute("car", car);
        model.addAttribute("maintenanceHistory", maintenanceHistory);

        return "car_maintenance_history";
    }

    @PostMapping("/update-car-status")
    public String updateCarStatus(@RequestParam int carId,
                                @RequestParam String maintenanceStatus,
                                @RequestParam String availabilityStatus,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        Optional<Car> carOpt = carRepository.findById(carId);
        if (carOpt.isPresent()) {
            Car car = carOpt.get();
            car.setMaintenanceStatus(maintenanceStatus);
            car.setAvailabilityStatus(availabilityStatus);
            carRepository.save(car);
            
            redirectAttributes.addFlashAttribute("message", "Car status updated successfully.");
        } else {
            redirectAttributes.addFlashAttribute("error", "Car not found.");
        }

        return "redirect:/admin/maintenance/dashboard";
    }

    @GetMapping("/feedback")
    public String viewFeedback(Model model, HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("role"))) {
            return "redirect:/adminLogin";
        }

        List<VehicleMaintenance> maintenanceWithFeedback = maintenanceRepository.findMaintenanceWithFeedback();
        model.addAttribute("maintenanceWithFeedback", maintenanceWithFeedback);

        return "maintenance_feedback";
    }
}
