package com.example.finalcarrentalsite.repository;

import com.example.finalcarrentalsite.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Integer> {
    List<Booking> findByDriver_Id(Integer id);
    List<Booking> findByDriver_Username(String username);
}
