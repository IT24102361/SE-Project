package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.Admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.example.finalcarrentalsite.repository.AdminRepository;

@Controller
public class AdminController {

    @Autowired
    private AdminRepository adminRepository;

    @PostMapping("/addAdmin")
    public ModelAndView addAdmin(@RequestParam String username,
                                 @RequestParam String password,
                                 @RequestParam String email) {
        Admin admin = new Admin();
        admin.setUsername(username);
        admin.setPassword(password);
        admin.setEmail(email);

        adminRepository.save(admin);  // Save to DB

        ModelAndView mv = new ModelAndView("admin"); // redirect to same page or a success page
        mv.addObject("message", "Admin added successfully!");
        return mv;
    }
    @GetMapping("/admin")
    public ModelAndView adminForm() {

        return new ModelAndView("admin"); // points to admin.html in templates
    }
    public String home() {
        return "admin"; // show admin.html by default
    }

}

