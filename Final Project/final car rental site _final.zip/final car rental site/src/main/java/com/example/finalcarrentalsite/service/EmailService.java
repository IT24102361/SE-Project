package com.example.finalcarrentalsite.service;

import com.example.finalcarrentalsite.entity.Booking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendBookingConfirmation(String toEmail, Booking booking) {
        if (toEmail == null || toEmail.isBlank()) return;
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(toEmail);
            // Make sure this matches spring.mail.username
            message.setFrom("kpmbimsara@gmail.com");
            message.setSubject("Your Car Booking Confirmation - ID " + booking.getBookingId());
            StringBuilder body = new StringBuilder();
            body.append("Thank you for your booking!\n\n");
            body.append("Booking ID: ").append(booking.getBookingId()).append("\n");
            if (booking.getCar() != null) {
                body.append("Car: ")
                    .append(booking.getCar().getBrand()).append(" ")
                    .append(booking.getCar().getModel()).append("\n");
                body.append("Type: ").append(booking.getCar().getType()).append("\n");
                body.append("Transmission: ").append(booking.getCar().getTransmission()).append("\n");
                body.append("Fuel: ").append(booking.getCar().getFuel()).append("\n");
            }
            body.append("Pickup Date: ").append(booking.getPickupDate()).append("\n");
            body.append("Dropoff Date: ").append(booking.getDropoffDate()).append("\n");
            body.append("Total Price: $").append(booking.getTotalPrice()).append("\n");
            body.append("Payment Status: ").append(booking.getPaymentStatus()).append("\n\n");
            body.append("We look forward to serving you.\n");
            message.setText(body.toString());
            mailSender.send(message);
        } catch (Exception ignored) {
        }
    }

    public void sendBookingConfirmation(String toEmail, Booking booking, double discount, String promotionCode) {
        if (toEmail == null || toEmail.isBlank()) return;
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(toEmail);
            // Make sure this matches spring.mail.username
            message.setFrom("kpmbimsara@gmail.com");
            message.setSubject("Your Car Booking Confirmation - ID " + booking.getBookingId());
            StringBuilder body = new StringBuilder();
            body.append("Thank you for your booking!\n\n");
            body.append("Booking ID: ").append(booking.getBookingId()).append("\n");
            if (booking.getCar() != null) {
                body.append("Car: ")
                    .append(booking.getCar().getBrand()).append(" ")
                    .append(booking.getCar().getModel()).append("\n");
                body.append("Type: ").append(booking.getCar().getType()).append("\n");
                body.append("Transmission: ").append(booking.getCar().getTransmission()).append("\n");
                body.append("Fuel: ").append(booking.getCar().getFuel()).append("\n");
            }
            body.append("Pickup Date: ").append(booking.getPickupDate()).append("\n");
            body.append("Dropoff Date: ").append(booking.getDropoffDate()).append("\n");
            
            if (discount > 0) {
                body.append("Original Price: $").append(String.format("%.2f", booking.getTotalPrice() + discount)).append("\n");
                body.append("Discount Applied: $").append(String.format("%.2f", discount)).append("\n");
                if (promotionCode != null && !promotionCode.trim().isEmpty()) {
                    body.append("Promotion Code Used: ").append(promotionCode).append("\n");
                }
            }
            
            body.append("Total Price: $").append(booking.getTotalPrice()).append("\n");
            body.append("Payment Status: ").append(booking.getPaymentStatus()).append("\n\n");
            body.append("We look forward to serving you.\n");
            message.setText(body.toString());
            mailSender.send(message);
        } catch (Exception ignored) {
        }
    }
}


