package com.example.finalcarrentalsite.repository;

import com.example.finalcarrentalsite.entity.Promotion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface PromotionRepository extends JpaRepository<Promotion, Integer> {
    
    // Find all active promotions
    List<Promotion> findByIsActiveTrue();
    
    // Find promotions active on a specific date
    @Query("SELECT p FROM Promotion p WHERE p.isActive = true AND p.startDate <= :date AND p.endDate >= :date")
    List<Promotion> findActivePromotionsOnDate(@Param("date") LocalDate date);
    
    // Find promotions by promotion code
    Optional<Promotion> findByPromotionCodeAndIsActiveTrue(String promotionCode);
    
    // Find promotions ending soon (within next 7 days)
    @Query("SELECT p FROM Promotion p WHERE p.isActive = true AND p.endDate BETWEEN :today AND :nextWeek")
    List<Promotion> findPromotionsEndingSoon(@Param("today") LocalDate today, @Param("nextWeek") LocalDate nextWeek);
    
    // Find promotions starting soon (within next 7 days)
    @Query("SELECT p FROM Promotion p WHERE p.isActive = true AND p.startDate BETWEEN :today AND :nextWeek")
    List<Promotion> findPromotionsStartingSoon(@Param("today") LocalDate today, @Param("nextWeek") LocalDate nextWeek);
    
    // Find expired promotions
    @Query("SELECT p FROM Promotion p WHERE p.endDate < :today")
    List<Promotion> findExpiredPromotions(@Param("today") LocalDate today);
    
    // Find promotions by name (case insensitive)
    List<Promotion> findByPromotionNameContainingIgnoreCaseAndIsActiveTrue(String promotionName);
    
    // Find weekend promotions (assuming weekend promotions have specific naming or conditions)
    @Query("SELECT p FROM Promotion p WHERE p.isActive = true AND (p.promotionName LIKE '%weekend%' OR p.description LIKE '%weekend%')")
    List<Promotion> findWeekendPromotions();
    
    // Find holiday promotions
    @Query("SELECT p FROM Promotion p WHERE p.isActive = true AND (p.promotionName LIKE '%holiday%' OR p.description LIKE '%holiday%')")
    List<Promotion> findHolidayPromotions();
}
