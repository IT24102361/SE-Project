package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.Admin;
import com.example.finalcarrentalsite.repository.AdminRepository;
import com.example.finalcarrentalsite.repository.UserRepository;
import com.example.finalcarrentalsite.repository.DriverRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminAuthController {

    @Autowired
    private AdminRepository adminRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private DriverRepository driverRepository;

    @GetMapping("/adminLogin")
    public String showLogin() {
        return "admin_login";
    }
    //requesting username and password for admin as the admin tries to log into the system.

    @PostMapping("/adminLogin")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          Model model,
                          HttpSession session) {
        Admin admin = adminRepository.findAll().stream()
                .filter(a -> username.equals(a.getUsername()) && password.equals(a.getPassword()))
                .findFirst()
                .orElse(null);
        if (admin == null) {
            model.addAttribute("error", "Invalid credentials");
            return "admin_login";
        }
        session.setAttribute("role", "ADMIN");
        session.setAttribute("username", admin.getUsername());
        model.addAttribute("users", userRepository.findAll());
        model.addAttribute("drivers", driverRepository.findAll());
        return "admin_dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
} 