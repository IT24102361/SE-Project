package com.example.finalcarrentalsite.repository;

import com.example.finalcarrentalsite.entity.TicketComment;
import com.example.finalcarrentalsite.entity.SupportTicket;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TicketCommentRepository extends JpaRepository<TicketComment, Integer> {
    List<TicketComment> findByTicketOrderByCreatedAtAsc(SupportTicket ticket);
}


