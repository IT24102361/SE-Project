package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.Promotion;
import com.example.finalcarrentalsite.service.PromotionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin/promotions")
public class PromotionController {
    
    @Autowired
    private PromotionService promotionService;
    
    // Display all promotions management page
    @GetMapping
    public String promotionsManagement(Model model) {
        List<Promotion> allPromotions = promotionService.getAllPromotions();
        List<Promotion> activePromotions = promotionService.getAllActivePromotions();
        List<Promotion> endingSoon = promotionService.getPromotionsEndingSoon();
        List<Promotion> startingSoon = promotionService.getPromotionsStartingSoon();
        
        model.addAttribute("allPromotions", allPromotions);
        model.addAttribute("activePromotions", activePromotions);
        model.addAttribute("endingSoon", endingSoon);
        model.addAttribute("startingSoon", startingSoon);
        
        return "promotion_management";
    }
    
    // Display create promotion form
    @GetMapping("/create")
    public String createPromotionForm(Model model) {
        model.addAttribute("promotion", new Promotion());
        return "promotion_create";
    }
    
    // Handle promotion creation
    @PostMapping("/create")
    public String createPromotion(@ModelAttribute Promotion promotion, 
                                 RedirectAttributes redirectAttributes) {
        try {
            promotionService.createPromotion(promotion);
            redirectAttributes.addFlashAttribute("successMessage", "Promotion created successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error creating promotion: " + e.getMessage());
        }
        return "redirect:/admin/promotions";
    }
    
    // Display edit promotion form
    @GetMapping("/edit/{id}")
    public String editPromotionForm(@PathVariable int id, Model model) {
        Optional<Promotion> promotion = promotionService.getPromotionById(id);
        if (promotion.isPresent()) {
            model.addAttribute("promotion", promotion.get());
            return "promotion_edit";
        } else {
            return "redirect:/admin/promotions";
        }
    }
    
    // Handle promotion update
    @PostMapping("/edit/{id}")
    public String updatePromotion(@PathVariable int id, @ModelAttribute Promotion promotion, 
                                 RedirectAttributes redirectAttributes) {
        try {
            promotion.setPromotionId(id);
            promotionService.updatePromotion(promotion);
            redirectAttributes.addFlashAttribute("successMessage", "Promotion updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error updating promotion: " + e.getMessage());
        }
        return "redirect:/admin/promotions";
    }
    
    // Toggle promotion active status
    @PostMapping("/toggle/{id}")
    public String togglePromotionStatus(@PathVariable int id, RedirectAttributes redirectAttributes) {
        try {
            Optional<Promotion> promotion = promotionService.getPromotionById(id);
            if (promotion.isPresent()) {
                if (promotion.get().getIsActive()) {
                    promotionService.deactivatePromotion(id);
                    redirectAttributes.addFlashAttribute("successMessage", "Promotion deactivated successfully!");
                } else {
                    promotionService.activatePromotion(id);
                    redirectAttributes.addFlashAttribute("successMessage", "Promotion activated successfully!");
                }
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error toggling promotion status: " + e.getMessage());
        }
        return "redirect:/admin/promotions";
    }
    
    // Delete promotion
    @PostMapping("/delete/{id}")
    public String deletePromotion(@PathVariable int id, RedirectAttributes redirectAttributes) {
        try {
            promotionService.deletePromotion(id);
            redirectAttributes.addFlashAttribute("successMessage", "Promotion deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error deleting promotion: " + e.getMessage());
        }
        return "redirect:/admin/promotions";
    }
    
    // Quick create weekend promotion
    @GetMapping("/create-weekend")
    public String createWeekendPromotionForm(Model model) {
        model.addAttribute("promotionType", "weekend");
        return "promotion_quick_create";
    }
    
    // Handle weekend promotion creation
    @PostMapping("/create-weekend")
    public String createWeekendPromotion(@RequestParam String promotionName,
                                       @RequestParam String description,
                                       @RequestParam double discountPercentage,
                                       @RequestParam LocalDate startDate,
                                       @RequestParam LocalDate endDate,
                                       RedirectAttributes redirectAttributes) {
        try {
            promotionService.createWeekendPromotion(promotionName, description, discountPercentage, startDate, endDate);
            redirectAttributes.addFlashAttribute("successMessage", "Weekend promotion created successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error creating weekend promotion: " + e.getMessage());
        }
        return "redirect:/admin/promotions";
    }
    
    // Quick create holiday promotion
    @GetMapping("/create-holiday")
    public String createHolidayPromotionForm(Model model) {
        model.addAttribute("promotionType", "holiday");
        return "promotion_quick_create";
    }
    
    // Handle holiday promotion creation
    @PostMapping("/create-holiday")
    public String createHolidayPromotion(@RequestParam String promotionName,
                                       @RequestParam String description,
                                       @RequestParam double discountPercentage,
                                       @RequestParam LocalDate startDate,
                                       @RequestParam LocalDate endDate,
                                       RedirectAttributes redirectAttributes) {
        try {
            promotionService.createHolidayPromotion(promotionName, description, discountPercentage, startDate, endDate);
            redirectAttributes.addFlashAttribute("successMessage", "Holiday promotion created successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error creating holiday promotion: " + e.getMessage());
        }
        return "redirect:/admin/promotions";
    }
    
    // View promotion details
    @GetMapping("/view/{id}")
    public String viewPromotionDetails(@PathVariable int id, Model model) {
        Optional<Promotion> promotion = promotionService.getPromotionById(id);
        if (promotion.isPresent()) {
            model.addAttribute("promotion", promotion.get());
            return "promotion_details";
        } else {
            return "redirect:/admin/promotions";
        }
    }
    
    // Search promotions
    @GetMapping("/search")
    public String searchPromotions(@RequestParam String searchTerm, Model model) {
        List<Promotion> searchResults = promotionService.searchPromotionsByName(searchTerm);
        model.addAttribute("searchResults", searchResults);
        model.addAttribute("searchTerm", searchTerm);
        return "promotion_search_results";
    }
    
    // Get promotions for specific date (API endpoint for booking system)
    @GetMapping("/api/active-for-date")
    @ResponseBody
    public List<Promotion> getActivePromotionsForDate(@RequestParam LocalDate date) {
        return promotionService.getActivePromotionsForDate(date);
    }
    
    // Get best promotion for date and price (API endpoint for booking system)
    @GetMapping("/api/best-promotion")
    @ResponseBody
    public Optional<Promotion> getBestPromotionForDate(@RequestParam LocalDate date, @RequestParam double price) {
        return promotionService.getBestPromotionForDate(date, price);
    }
    
    // Calculate discount (API endpoint for booking system)
    @GetMapping("/api/calculate-discount")
    @ResponseBody
    public double calculateDiscount(@RequestParam double price, 
                                  @RequestParam LocalDate date, 
                                  @RequestParam(required = false) String promotionCode) {
        return promotionService.calculateDiscountForBooking(price, date, promotionCode);
    }

    // Public promotions page for customers
    @GetMapping("/public")
    public String publicPromotions(Model model) {
        List<Promotion> activePromotions = promotionService.getAllActivePromotions();
        model.addAttribute("activePromotions", activePromotions);
        return "promotions";
    }
}
