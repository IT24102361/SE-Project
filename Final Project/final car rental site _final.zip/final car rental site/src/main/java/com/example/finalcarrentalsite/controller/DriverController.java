package com.example.finalcarrentalsite.controller;

import com.example.finalcarrentalsite.entity.Driver;
import com.example.finalcarrentalsite.repository.DriverRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
public class DriverController {

    @Autowired
    private DriverRepository driverRepository;

    @GetMapping("/driver/register")
    public String showRegister() {
        return "driver_register";
    }

    @PostMapping("/driver/register")
    public String doRegister(@RequestParam String username,
                             @RequestParam String password,
                             @RequestParam String email,
                             @RequestParam String phoneNumber,
                             @RequestParam String licenseNumber,
                             Model model,
                             HttpSession session) {
        Driver driver = new Driver();
        driver.setUsername(username);
        driver.setPassword(password);
        driver.setEmail(email);
        driver.setPhoneNumber(phoneNumber);
        driver.setLicenseNumber(licenseNumber);
        driverRepository.save(driver);
        session.setAttribute("role", "DRIVER");
        session.setAttribute("username", driver.getUsername());
        model.addAttribute("message", "Registration successful. You are now logged in.");
        return "redirect:/";
    }

    @GetMapping("/driver/login")
    public String showLogin() {
        return "driver_login";
    }

    @PostMapping("/driver/login")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          Model model,
                          HttpSession session) {
        Optional<Driver> existing = driverRepository.findByUsernameAndPassword(username, password);
        if (existing.isPresent()) {
            session.setAttribute("role", "DRIVER");
            session.setAttribute("username", existing.get().getUsername());
            model.addAttribute("driver", existing.get());
            return "redirect:/driver/dashboard"; // redirect to driver dashboard
        }
        model.addAttribute("error", "Invalid credentials");
        return "driver_login";
    }

    // Driver Dashboard
    @Autowired
    private com.example.finalcarrentalsite.repository.BookingRepository bookingRepository;

    @GetMapping("/driver/dashboard")
    public String driverDashboard(HttpSession session, Model model) {
        Object role = session.getAttribute("role");
        Object username = session.getAttribute("username");
        if (role == null || username == null || !"DRIVER".equals(role)) {
            return "redirect:/driver/login";
        }

        Optional<Driver> driverOpt = driverRepository.findByUsername(username.toString());
        if (driverOpt.isEmpty()) {
            return "redirect:/driver/login";
        }

        Driver driver = driverOpt.get();
        java.util.List<com.example.finalcarrentalsite.entity.Booking> all = bookingRepository.findByDriver_Id(driver.getId());

        java.time.LocalDate today = java.time.LocalDate.now();
        java.util.List<com.example.finalcarrentalsite.entity.Booking> todays = new java.util.ArrayList<>();
        java.util.List<com.example.finalcarrentalsite.entity.Booking> upcoming = new java.util.ArrayList<>();
        double earnings = 0.0;

        for (com.example.finalcarrentalsite.entity.Booking b : all) {
            if (b.getPickupDate() != null) {
                if (b.getPickupDate().isEqual(today)) {
                    todays.add(b);
                } else if (b.getPickupDate().isAfter(today)) {
                    upcoming.add(b);
                }
            }
            // naive earnings: sum all booking totals; adjust later if status is introduced
            earnings += b.getTotalPrice();
        }

        model.addAttribute("driver", driver);
        model.addAttribute("todaysBookings", todays);
        model.addAttribute("upcomingBookings", upcoming);
        model.addAttribute("totalBookings", all.size());
        model.addAttribute("earnings", earnings);

        return "driver_dashboard";
    }
} 