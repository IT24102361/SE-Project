import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnect {
    public static void main(String[] args) {
        // Connection details
        String url = "jdbc:sqlserver://localhost:1433;databaseName=VehicleRentalDB;encrypt=true;trustServerCertificate=true;";
        String user = "sa";   // replace with SQL username
        String password = "islahsql@003";

        try {
            // Create connection
            Connection conn = DriverManager.getConnection(url,user,password);
            System.out.println("✅ Connection successful!");

            // Close connection
            conn.close();
        } catch (SQLException e) {
            System.out.println("❌ Connection failed!");
            e.printStackTrace();
        }
    }
}
